package GameRole;

public class AFactory extends Factory {
	
	public Role CreateRole() {
		
		return new Arthur();
		
	}

}
