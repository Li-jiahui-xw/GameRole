package GameRole;

public class DFactory extends Factory {
	
	public Role CreateRole() {
		
		return new Daji();
		
	}

}
