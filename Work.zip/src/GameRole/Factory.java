package GameRole;

public class Factory {
	
	public Role CreateRole() {
		
		return null;
		
	}


}
