package GameRole;

public class Role {

	public void play() {
		
	}
	
}
